# The dav1d project and VideoLAN association would like to thank

## AOM
The Alliance for Open Media (AOM) for partially funding this project.

## Companies
* Two Orioles LLC, for important coding effort
* VideoLabs SAS

## Projects
* VideoLAN
* FFmpeg
* libplacebo

## Individual

And all the dav1d Authors (git shortlog -sn), including:

Henrik Gramner, Martin Storsjö, Ronald S. Bultje, Janne Grunau, James Almer,
Victorien Le Couviour--Tuffet, Matthias Dressel, Nathan E. Egge,
Jean-Baptiste Kempf, Marvin Scholz, Luc Trudeau, Niklas Haas,
Hugo Beauzée-Luyssen, Konstantin Pavlov, David Michael Barr, Steve Lhomme,
yuanhecai, Luca Barbato, Wan-Teh Chang, Kyle Siefring, B Krishnan Iyer,
Francois Cartegnie, Liwei Wang, David Conrad, Derek Buitenhuis, Jan Beich,
Michael Bradshaw, Raphaël Zumer, Xuefeng Jiang, Arpad Panyik, Christophe Gisquet,
Justin Bull, Boyuan Xiao, Dale Curtis, Emmanuel Gil Peyrot, Raphael Zumer,
Rupert Swarbrick, Thierry Foucu, Thomas Daede, jinbo, André Kempe, Colin Lee,
Jonathan Wright, Lynne, Michail Alvanos, Nico Weber, Salome Thirot, SmilingWolf,
Tristan Laurent, Tristan Matthews, Vittorio Giovara, Yannis Guyon,
Andrey Semashev, Anisse Astier, Anton Mitrofanov, Charlie Hayden, Dmitriy Sychov,
Ewout ter Hoeven, Fred Barbier, Hao Chen, Jean-Yves Avenard, Joe Drago,
Mark Shuttleworth, Matthieu Bouron, Mehdi Sabwat, Nicolas Frattaroli,
Pablo Stebler, Rostislav Pehlivanov, Sebastian Dröge, Shiz, Steinar Midtskogen,
Sylvain BERTRAND, Sylvestre Ledru, Timo Gurr, Vibhoothi,
Vignesh Venkatasubramanian, Xavier Claessens, Xu Guangxin, kossh1 and skal.
